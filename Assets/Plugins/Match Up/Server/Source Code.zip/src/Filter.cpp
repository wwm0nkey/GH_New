#include "Filter.h"

const string Filter::OPS[6] = {"=", "!=", "LIKE", "NOT LIKE", "<", ">"};
const string Filter::TYPES[3] = {"STRING", "INT", "FLOAT"};
const string Filter::TYPE_TABLES[3] = {"stringData", "intData", "floatData"};
