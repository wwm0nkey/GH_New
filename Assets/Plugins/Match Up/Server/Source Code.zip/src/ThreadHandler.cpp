#include "ThreadHandler.h"

using namespace std;

//Need to actually "allocate" static member
pthread_mutex_t ThreadHandler::mutex = PTHREAD_MUTEX_INITIALIZER;

ThreadHandler::ThreadHandler() {}

int ThreadHandler::Create(void *Callback, void *args) 
{
  int tret=0;
 
  //Supercreepy typecast
  tret = pthread_create(&this->tid, NULL, (void *(*)(void *))Callback, args);

  if(tret) 
  { 
    cerr << "Error while creating threads." << "\n";
    return tret;
  }
  else 
  {
    //cout << "Thread successfully created." << endl;
    return 0;
  }
}

void ThreadHandler::Cancel()
{
    pthread_cancel(tid);
}

void ThreadHandler::Join() 
{
  pthread_join(tid, NULL);
}

bool ThreadHandler::InitMutex() 
{
	/*if(pthread_mutex_init(&ThreadHandler::mutex, NULL) < 0)
	{
	  cerr << "Error while initializing mutex" << "\n";
	  return false;
	}
	else
	{
	  return true;
	}*/
		return true;
}

/*
    LockMutex():
    Blocks until mutex becomes available
*/
bool ThreadHandler::LockMutex(const char *identifier) 
{
  if(pthread_mutex_lock(&ThreadHandler::mutex) == 0) 
  {
    return true;
  }
  else 
  {
   cerr << "Error while " << identifier << " was trying to acquire the lock" << "\n";
   return false;
  }
}

bool ThreadHandler::UnlockMutex(const char *identifier) 
{
  if(pthread_mutex_unlock(&ThreadHandler::mutex) == 0) 
  {
    return true;
  }
  else 
  {
   cerr << "Error while " << identifier << " was trying to release the lock" << "\n";
   return false;
  }
}
