#ifndef __THREAD_HANDLER_H__
#define __THREAD_HANDLER_H__

#include <iostream>
#include <string>

#if defined(_WIN32) || defined(_WIN64)
#include <WinSock2.h>
#include <WS2tcpip.h>
#pragma comment(lib, "ws2_32")
#endif

#if defined(_WIN32) || defined(_WIN64)
  #include "pthread-win32/pthread.h"
#else
  #include <unistd.h>
#endif
#include <cstdlib>

using namespace std;

/**
 * Keeps track of thread id and mutex for locking and clean up
 */
class ThreadHandler 
{
  public:
    // The id of the thread
    pthread_t tid;

  private:
    // For locking access to shared resources
    static pthread_mutex_t mutex;

  public:
    /**
     * Create a new ThreadHandler instance
     */
    ThreadHandler();

    /**
     * Spawn the thread and call the Callback method
     */
    int Create(void *Callback, void *args);
    
    /**
     * Cancel the thread
     */
    void Cancel();

    /**
     * Join the thread back to the calling thread
     */
    void Join();

    /**
     * Initialize the mutex
     */
    static bool InitMutex();

    /**
     * Block until mutex becomes available on then lock it 
     */
    static bool LockMutex(const char *identifier);
  
    /**
     * Unlock mutex
     */
    static bool UnlockMutex(const char *identifier);
};

#endif
