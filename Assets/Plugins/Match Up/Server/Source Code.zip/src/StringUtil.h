#ifndef __STRINGUTIL_H__
#define __STRINGUTIL_H__

#include <sstream>
#include <string>
#include <vector>
#include <regex>
#include "Debug.h"
#include <climits>
#include <cfloat>

using namespace std;

class StringUtil
{
public:
	// Like stol except instead of throwing an exception when it fails it outputs a message and returns LONG_MAX
	static long long try_stol(string s, string debugMessage)
	{
		try
		{
			return stoll(s);
		}
		catch (const invalid_argument&)
		{
			Debug::Log(debugMessage + ". Failed to parse int from string: " + s, true);
		}
		catch (const out_of_range&)
		{
			Debug::Log(debugMessage + ". Failed to parse int from string (argument out of range): " + s, true);
		}

		return LONG_MAX;
	}

	// Like stod except instead of throwing an exception when it fails it outputs a message and returns DBL_MAX
	static double try_stod(string s, string debugMessage)
	{
		try
		{
			return stod(s);
		}
		catch (const invalid_argument&)
		{
			Debug::Log(debugMessage + ". Failed to parse double from string: " + s, true);
		}
		catch (const out_of_range&)
		{
			Debug::Log(debugMessage + ". Failed to parse double from string (argument out of range): " + s, true);
		}

		return DBL_MAX;
	}

	/**
	 * A useful way to split a string
	 */
	/*template <typename Container>
	Container& split(
		const typename Container::value_type& s,
		typename Container::value_type::value_type delimiter,
		Container& result)
	{
		result.clear();
		istringstream ss(s);
		while (!ss.eof())
		{
			typename Container::value_type field;
			getline(ss, field, delimiter);
			result.push_back(field);
		}
		return result;
	};*/

	/**
	 * Parse some quoted text and return it without quotes.
	 * Also sets endPos to the position of the closing quote.
	 */
	static string parseQuoted(string text, size_t startPos, size_t* endPos)
	{
		startPos++; // For starting quote
		int lastQuotePos = startPos;
		while (true)
		{
			*endPos = text.find('"', lastQuotePos);
			lastQuotePos = *endPos + 1;
			if (*endPos == string::npos)
			{
				Debug::Error("Failed parsing match data string. Found open quote with no closing quote: " + text);
				return "";
			}
			if (text[*endPos - 1] != '\\')
			{
				// Found the non-escaped closing quote
				break;
			}
		}
		string parsed = text.substr(startPos, (*endPos - startPos));
		*endPos = *endPos + 1; // For ending quote
		return parsed;
	}
};
#endif
