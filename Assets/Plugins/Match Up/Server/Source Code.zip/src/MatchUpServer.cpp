#include "MatchUpServer.h"
#include "Debug.h"
#include "DB.h"
#include "Server.h"
#include "ThreadHandler.h"

using namespace std;

Server* MatchUpServer::server = NULL;

const string MatchUpServer::COMMANDS[7] = {
  "Get Match",
  "Get Match List", 
  "Create Match", 
  "Destroy Match", 
  "Join Match", 
  "Leave Match", 
  "Set Match Data"
};

void MatchUpServer::StartServer(string* ip, int ipCount,  int port)
{
  ThreadHandler::LockMutex("DB Create tables");
  sqlite3* db;
  int rc = sqlite3_open("MatchUpServer.db", &db);
  if(rc)
  {
    Debug::Error("Can't open database");
  }

  // Create tables if they don't exist
  char* err;
  string q = "PRAGMA foreign_keys = on";
  sqlite3_exec(db, &q[0], NULL, 0, &err);
  if (err) Debug::SqlError(err);

  q = "CREATE TABLE IF NOT EXISTS Matches (";
  q += " id INTEGER primary key autoincrement,";
  q += " hostClientID int,";
  q += " name varchar(64),";
  q += " maxClients int,";
  q += " createdOn timestamp not null default current_timestamp";
  q += ")";
  sqlite3_exec(db, &q[0], NULL, 0, &err);
  if (err) Debug::SqlError(err);

  q = "CREATE TABLE IF NOT EXISTS Clients (";
  q += " id INTEGER primary key autoincrement,";
  q += " socketID int not null,";
  q += " matchID int not null,";
  q += " createdOn timestamp not null default current_timestamp,";
  q += " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE";
  q += ")";
  sqlite3_exec(db, &q[0], NULL, 0, &err);
  if (err) Debug::SqlError(err);

  q = "CREATE TABLE IF NOT EXISTS FloatData (";
  q += " matchID int not null,";
  q += " key char(64) not null,";
  q += " value float not null default 0,";
  q += " PRIMARY KEY (matchID, key) ON CONFLICT REPLACE,";
  q += " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE";
  q += ")";
  sqlite3_exec(db, &q[0], NULL, 0, &err);
  if (err) Debug::SqlError(err);

  q = "CREATE TABLE IF NOT EXISTS IntData (";
  q += " matchID int not null,";
  q += " key char(64) not null,";
  q += " value int not null default 0,";
  q += " PRIMARY KEY (matchID, key) ON CONFLICT REPLACE,";
  q += " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE";
  q += ")";
  sqlite3_exec(db, &q[0], NULL, 0, &err);
  if (err) Debug::SqlError(err);

  q = "CREATE TABLE IF NOT EXISTS StringData (";
  q += " matchID int not null,";
  q += " key char(64) not null,";
  q += " value varchar not null default \"\",";
  q += " PRIMARY KEY (matchID, key) ON CONFLICT REPLACE,";
  q += " FOREIGN KEY (matchID) REFERENCES Matches(id) ON DELETE CASCADE";
  q += ")";
  sqlite3_exec(db, &q[0], NULL, 0, &err);
  if (err) Debug::SqlError(err);

  ThreadHandler::UnlockMutex("DB Create tables");

  MatchUpServer::ClearMatches(db);

  ThreadHandler::LockMutex("DB Close");
  sqlite3_close(db);
  ThreadHandler::UnlockMutex("DB Close");

  // Initialize server
  server = new Server(ip, ipCount, port);
  server->AcceptAndDispatch();
}

void MatchUpServer::CleanUp()
{
  Server::CleanUp();
  delete server;
}

string MatchUpServer::ReceivedCommand(string messageString, sqlite3* db, int socketID, string* transactionID)
{
  int firstPipePos = messageString.find('|');
  string commandString = messageString.substr(0, firstPipePos);
  int secondPipePos = messageString.find('|', firstPipePos + 1);
  *transactionID = messageString.substr(firstPipePos + 1, secondPipePos - (firstPipePos + 1));
  string theRestOfTheMessage = messageString.substr(secondPipePos + 1);

  long long commandID = StringUtil::try_stol(commandString, "Parsing command ID");
  if (commandID == LONG_MAX) return "";
  Command command = (Command)commandID;

  Debug::Log("Received command [" + COMMANDS[(int)command] + "][" + *transactionID + "]: " + theRestOfTheMessage);

  // Route commands to appropriate methods
  switch(command)
  {
	case GET_MATCH:
	  {
		// Get the page number
		size_t start = 0;
		size_t end = theRestOfTheMessage.find(",", start);
		string matchIDString = theRestOfTheMessage.substr(start, end - start);
		long long matchID = StringUtil::try_stol(matchIDString, "Pasing matchID");
		if (matchID == LONG_MAX) return "";
		start = end + 1;

		return GetMatch(db, matchID);
	  }
    case GET_MATCH_LIST:
      {
        // Get the page number
        size_t start = 0;
        size_t end = theRestOfTheMessage.find(",", start);
		string pageNumberStr = theRestOfTheMessage.substr(start, end - start);
        long long page = StringUtil::try_stol(pageNumberStr, "Parsing page number");
		if (page == LONG_MAX) return "";
        start = end + 1;

        // Get the number of results per page
        end = theRestOfTheMessage.find(",", start);
		string numResultsStr = theRestOfTheMessage.substr(start, end - start);
        long long resultsPerPage = StringUtil::try_stol(numResultsStr, "Parsing results per page");
		if (resultsPerPage == LONG_MAX) return "";
        start = end + 1;
        
        // Get the flag that tells us whether or not to include match data in the results
        end = theRestOfTheMessage.find("|", start);
        if (end == string::npos) end = theRestOfTheMessage.length();
        string matchDataFlag = theRestOfTheMessage.substr(start, (end - start));
        long long includeMatchData = StringUtil::try_stol(matchDataFlag, "Parsing includeMatchData flag");
		if (includeMatchData == LONG_MAX) return "";
        start = end + 1;
        
        vector<Filter> filters;
        if (start < theRestOfTheMessage.length())
        {
          // The rest of the message will be parsed as filters
          theRestOfTheMessage = theRestOfTheMessage.substr(start);
          
          // Get the filters
          filters = ParseFilters(theRestOfTheMessage);
        }

        // Finally get the actual match list
        return GetMatchList(db, filters, page, resultsPerPage, includeMatchData != 0); 
      }
      break;
    case CREATE_MATCH: 
      {
        // First parse everything to get the matchName, macClients, and match data.
        string matchName;
        int maxClients;
		vector<Filter> filters;
		try 
		{
			filters = ParseCreateMatchRequest(theRestOfTheMessage, &matchName, &maxClients);
		}
		catch (const string*)
		{
			return "";
		}
        // Then create the match using that info
        return CreateMatch(db, socketID, matchName, maxClients, filters); 
      }
      break;
    case DESTROY_MATCH: 
      {
        // Get the matchID to destroy
        long long id = StringUtil::try_stol(theRestOfTheMessage, "Parsing match ID");
		if (id == LONG_MAX) return "";

        // Destroy the match
        return DestroyMatch(db, id); 
      }
      break;
    case ADD_CLIENT_TO_MATCH: 
      {
        // Get the matchID to add the client to
        long long id = StringUtil::try_stol(theRestOfTheMessage, "Parsing match ID");
		if (id == LONG_MAX) return "";
        // Add the client, making sure to keep track of which socket they belong to
        return AddClientToMatch(db, socketID, id); 
      }
      break;
    case REMOVE_CLIENT_FROM_MATCH: 
      {
        // Get the clientID of the client to remove
        long long id = StringUtil::try_stol(theRestOfTheMessage, "Parsing match ID");
		if (id == LONG_MAX) return "";
        // Remove them
        return RemoveClientFromMatch(db, id); 
      }
      break;
    case SET_MATCH_DATA:
      {
        // Make sure data was provided
        size_t end = theRestOfTheMessage.find("|");
        if (end == string::npos) return "";
        // Get the matchID that we're setting match data for
		string matchIDStr = theRestOfTheMessage.substr(0, end);
        long long matchID = StringUtil::try_stol(matchIDStr, "Parsing match ID");
		if (matchID == LONG_MAX) return "";
        end++;
        // Prase the rest of the message as match data
        theRestOfTheMessage = theRestOfTheMessage.substr(end, theRestOfTheMessage.length()-end);
        vector<Filter> filters = ParseFilters(theRestOfTheMessage, false);
        // Set the match data for the match
        SetMatchData(db, matchID, filters);
        return "";
      }
    default:
      return "";
  }
  
  return ""; // Not actually possible to get here but it makes a warning go away
}

string MatchUpServer::CreateMatch(sqlite3* db, int socketID, string matchName, int maxClients, vector<Filter> matchData)
{
  string q = "INSERT INTO Matches (name, maxClients) VALUES (?, ?)";

  sqlite3_stmt* st;
  bool success = DB::Prep(db, &st, q, "CreateMatch preparing sql statement");
  if (!success) return "";

  success = DB::Bind(db, st, 1, matchName, "CreateMatch binding match name");
  if (!success) return "";

  success = DB::Bind(db, st, 2, maxClients, "CreateMatch binding maxClients");
  if (!success) return "";

  success = DB::Step(db, st, "CreateMatch fetching results");
  if (!success) return "";

  sqlite3_finalize(st);

  ThreadHandler::LockMutex("DB Last insert id");
  
  // Match created succesfully, add host
  long matchID = (long)sqlite3_last_insert_rowid(db);
  Debug::Log("Match created " + to_string(matchID));
  
  ThreadHandler::UnlockMutex("DB Last insert id");

  string clientIDStr = AddClientToMatch(db, socketID, matchID);
  if (clientIDStr == "") return "";

  // Set client as host
  long long clientID = StringUtil::try_stol(clientIDStr, "Parsing client ID");
  if (clientID == LONG_MAX) return "";

  success = SetMatchHost(db, matchID, clientID);
  if (!success) return "";

  // Add match data
  if (matchData.size() > 0)
  {    
    success = SetMatchData(db, matchID, matchData);
    if (!success) return "";
  }
  
  return to_string((long long)matchID) + "," + clientIDStr;
}

bool MatchUpServer::SetMatchHost(sqlite3* db, long long matchID, long long clientID)
{
  bool success;
  sqlite3_stmt* st;

  string q = "UPDATE Matches SET hostClientID = ? WHERE id = ?";

  success = DB::Prep(db, &st, q, "SetMatchHost preparing query");
  if (!success) return false;

  success = DB::Bind(db, st, 1, clientID, "SetMatchHost bind clientID");
  if (!success) return false;

  success = DB::Bind(db, st, 2, matchID, "SetMatchHost bind matchID");
  if (!success) return false;

  success = DB::Step(db, st, "SetMatchHost executing query");
  if (!success) return false;

  sqlite3_finalize(st);

  return true;
}

void MatchUpServer::HandleSocketDisconnect(sqlite3* db, int socketID)
{
  DestroyMatchForSocket(db, socketID);
  RemoveClientForSocket(db, socketID);
}

void MatchUpServer::DestroyMatchForSocket(sqlite3* db, int socketID)
{
  string q;
  bool success;
  sqlite3_stmt* st;

  q =  "DELETE FROM Matches ";
  q += "WHERE hostClientID IN (";
  q += "  SELECT id FROM Clients WHERE socketID = ?";
  q += ")";

  success = DB::Prep(db, &st, q, "DestroyMatchForSocket preparing query");
  if (!success) return;

  success = DB::Bind(db, st, 1, socketID, "DestroyMatchForSocket bind socketID");
  if (!success) return;

  success = DB::Step(db, st, "DestroyMatchForSocket deleting match");
  if (!success) return;

  sqlite3_finalize(st);

  Debug::Log("Destroyed match for socket ID: " + to_string((long long)socketID));
}

void MatchUpServer::RemoveClientForSocket(sqlite3* db, int socketID)
{
  bool success;
  sqlite3_stmt* st;

  string q = "DELETE FROM Clients WHERE socketID = ?";

  success = DB::Prep(db, &st, q, "RemoveClientForSocket preparing query");
  if (!success) return;

  success = DB::Bind(db, st, 1, socketID, "RemoveClientForSocket bind socketID");
  if (!success) return;

  success = DB::Step(db, st, "RemoveClientForSocket deleting client");
  if (!success) return;

  sqlite3_finalize(st);

  Debug::Log("Removed Client for socket ID: " + to_string((long long)socketID));
}

string MatchUpServer::ClearMatchData(sqlite3* db, long long matchID)
{
  bool success = ClearMatchDataForType(db, matchID, Filter::STRING);
  success = ClearMatchDataForType(db, matchID, Filter::FLOAT) && success;
  success = ClearMatchDataForType(db, matchID, Filter::INT) && success;

  return "";
}

bool MatchUpServer::ClearMatchDataForType(sqlite3* db, long long matchID, Filter::ValueType type)
{
  string q = "DELETE FROM " + Filter::TYPE_TABLES[type] + " WHERE matchID = ?";
  
  sqlite3_stmt *st;
  bool success = DB::Prep(db, &st, q, "ClearMatchData preparing sql statement");
  if (!success) return false;

  success = DB::Bind(db, st, 1, matchID, "ClearMatchData binding matchID");
  if (!success) return false;
  
  success = DB::Step(db, st, "ClearMatchData executing sql");
  if (!success) return false;

  sqlite3_finalize(st);

  Debug::Log("Cleared matchData of type " + Filter::TYPES[type] + " for match " + to_string((long long)matchID));

  return true;
}

bool MatchUpServer::SetMatchData(sqlite3* db, long long matchID, vector<Filter> matchData)
{
  bool success = SetMatchDataForType(db, matchID, matchData, Filter::STRING);
  success = SetMatchDataForType(db, matchID, matchData, Filter::FLOAT) && success;
  success = SetMatchDataForType(db, matchID, matchData, Filter::INT) && success;

  return success;
}

bool MatchUpServer::DeleteConflictingDataForType(sqlite3* db, long long matchID, vector<Filter> matchData, Filter::ValueType type)
{
  string tableName = Filter::TYPE_TABLES[type];

  string q = "DELETE FROM " + tableName + " WHERE matchID = ? AND key IN (";
  for (size_t i = 0; i < matchData.size(); i++)
  {
    Filter data = matchData[i];
    q += "?,";
  }
  q = q.substr(0, q.length() - 1); // Remove trailing comma
  q += ")";

  sqlite3_stmt* st;
  bool success = DB::Prep(db, &st, q, "DeleteConflictingMatchData preparing sql statement");
  if (!success) return false;

  int i = 1;

  success = DB::Bind(db, st, i, matchID, "DeleteConflictingMatchData binding matchID");
  if (!success) return false;
  i++;

  for (size_t dataIndex = 0; dataIndex < matchData.size(); dataIndex++)
  {
    Filter data = matchData[dataIndex];
    success = DB::Bind(db, st, i, data.key, "DeleteConflictingMatchData binding key: " + data.key);
    if (!success) return false;
    i++;
  }

  success = DB::Step(db, st, "DeleteConflictingMatchData executing query");
  if (!success) return false;

  sqlite3_finalize(st);

  return true;
}

bool MatchUpServer::SetMatchDataForType(sqlite3* db, long long matchID, vector<Filter> matchData, Filter::ValueType type)
{
  string tableName = Filter::TYPE_TABLES[type];

  bool success = DeleteConflictingDataForType(db, matchID, matchData, type);
  if (!success) return false;

  string q = "INSERT INTO " + tableName + " (matchID, key, value) VALUES";
  bool hasAny = false;
  for (size_t i = 0; i < matchData.size(); i++)
  {
    Filter data = matchData[i];
    if (data.valueType != type) continue;
    q += " (?, ?, ?),";
    hasAny = true;
  }
  if (!hasAny) return true;
  q = q.substr(0, q.length() - 1); // Remove trailing comma

  sqlite3_stmt* st;
  success = DB::Prep(db, &st, q, "SetMatchData preparing sql statement");
  if (!success) return false;

  int i = 1;
  for (size_t dataIndex = 0; dataIndex < matchData.size(); dataIndex++)
  {
    Filter data = matchData[dataIndex];
    if (data.valueType != type) continue;

    success = DB::Bind(db, st, i, matchID, "SetMatchData binding matchID");
    if (!success) return false;
    i++;

    success = DB::Bind(db, st, i, data.key, "SetMatchData binding key");
    if (!success) return false;
    i++;

    switch(data.valueType)
    {
      case Filter::STRING:
        success = DB::Bind(db, st, i, data.stringValue, "SetMatchData binding string value");
        break;
      case Filter::FLOAT:
        success = DB::Bind(db, st, i, data.floatValue, "SetMatchData binding float value");
        break;
      case Filter::INT:
        success = DB::Bind(db, st, i, data.intValue, "SetMatchData binding int value");
        break;
    }
    if (!success) return false;
    i++;
  }
 
  success = DB::Step(db, st, "SetMatchData fetching results");
  if (!success) return false;

  sqlite3_finalize(st);

  return true;
}

string MatchUpServer::AddClientToMatch(sqlite3* db, int socketID, long long matchID)
{
  string q = "INSERT INTO Clients (matchID, socketID) VALUES (?, ?)";
  sqlite3_stmt* st;

  bool success = DB::Prep(db, &st, q, "AddClientToMatch preparing sql statement");
  if (!success) return "";

  success = DB::Bind(db, st, 1, matchID, "AddClientToMatch binding matchID");
  if (!success) return "";
  
  success = DB::Bind(db, st, 2, socketID, "AddClientToMatch binding socketID");
  if (!success) return "";
  
  success = DB::Step(db, st, "AddClientToMatch fetching results");
  if (!success) return "";

  sqlite3_finalize(st);
 
  ThreadHandler::LockMutex("DB Last insert id");
  sqlite_int64 clientID = sqlite3_last_insert_rowid(db);
  string responseText = to_string((long long)clientID);
  ThreadHandler::UnlockMutex("DB Last insert id");

  Debug::Log("Added client " + to_string((long long)clientID) + " to match " + to_string((long long)matchID));

  string matchDataString = "";
  int numDatas = 0;

  string intData = EncodeMatchData(db, matchID, Filter::INT, &numDatas);
  if (intData != "") matchDataString += intData + "|";

  string floatData = EncodeMatchData(db, matchID, Filter::FLOAT, &numDatas);
  if (floatData != "") matchDataString += floatData + "|";

  string stringData = EncodeMatchData(db, matchID, Filter::STRING, &numDatas);
  if (stringData != "") matchDataString += stringData + "|";

  if (numDatas > 0)
  {
    responseText += "," + to_string((long long)numDatas);
    responseText += "|";
    responseText += matchDataString;
    responseText = responseText.substr(0, responseText.length()-1);
  }

  return responseText;
}

void MatchUpServer::ClearMatches(sqlite3* db)
{
	string q = "DELETE FROM Matches";

	sqlite3_stmt* st;
	bool success = DB::Prep(db, &st, q, "DestroyMatch preparing sql statement");
	if (!success) return;

	success = DB::Step(db, st, "DestroyMatch executing sql");
	if (!success) return;

	sqlite3_finalize(st);
}

string MatchUpServer::DestroyMatch(sqlite3* db, long long matchID)
{
  string q = "DELETE FROM Matches WHERE id = ?";

  sqlite3_stmt* st;
  bool success = DB::Prep(db, &st, q, "DestroyMatch preparing sql statement");
  if (!success) return "";

  success = DB::Bind(db, st, 1, matchID, "DestroyMatch binding matchID");
  if (!success) return "";
  
  success = DB::Step(db, st, "DestroyMatch executing sql");
  if (!success) return "";

  sqlite3_finalize(st);

  Debug::Log("Destroyed match " + to_string((long long)matchID));

  return "";
}

string MatchUpServer::RemoveAllClientsFromMatch(sqlite3* db, long long matchID)
{
  string q = "DELETE FROM Clients WHERE matchID = ?";
  
  sqlite3_stmt *st;
  bool success = DB::Prep(db, &st, q, "RemoveAllClientsFromMatch preparing sql statement");
  if (!success) return "";

  success = DB::Bind(db, st, 1, matchID, "RemoveAllClientsFromMatch binding matchID");
  if (!success) return "";
  
  success = DB::Step(db, st, "RemoveAllClientsFromMatch executing sql");
  if (!success) return "";

  sqlite3_finalize(st);

  Debug::Log("Removed all clients from match " + to_string((long long)matchID));

  return "";
}

string MatchUpServer::RemoveClientFromMatch(sqlite3* db, long long clientID)
{
  string q = "DELETE FROM Clients WHERE id = ?";

  sqlite3_stmt *st;
  bool success = DB::Prep(db, &st, q, "RemoveClientFromMatch preparing sql statement");
  if (!success) return "";

  success = DB::Bind(db, st, 1, clientID, "RemoveClientFromMatch binding clientID");
  if (!success) return "";
  
  success = DB::Step(db, st, "RemoveClientFromMatch executing sql");
  if (!success) return "";

  sqlite3_finalize(st);

  Debug::Log("Removed client " + to_string((long long)clientID));

  return "";
}

vector<Filter> MatchUpServer::ParseFilters(string matchDataString, bool isFilter)
{
  vector<Filter> filters;
  if (matchDataString == "") return filters;
  size_t startPos = 0;
  size_t endPos = matchDataString.find(",", startPos);
  while (endPos != string::npos && endPos < matchDataString.length())
  {
    // Value type
    endPos = matchDataString.find(",", startPos);
	string filterValueTypeStr = matchDataString.substr(startPos, endPos - startPos);
	long long filterValueTypeInt = StringUtil::try_stol(filterValueTypeStr, "Parsing filter value type");
	if (filterValueTypeInt == LONG_MAX) return filters;
	  Filter::ValueType type = (Filter::ValueType)filterValueTypeInt;
	  startPos = endPos + 1;

    // Key
	  endPos = matchDataString.find(",", startPos);
	  string key = matchDataString.substr(startPos, (endPos-startPos));
	  startPos = endPos + 1;

    // Value
	  string valueText;
	  if (type == Filter::STRING)
	  {
      valueText = StringUtil::parseQuoted(matchDataString, startPos, &endPos);

      if (endPos == string::npos)
	    {
	      vector<Filter> filters;
	      return filters;
	    }
	    startPos = endPos + 1;
	  }
	  else
	  {
      if (isFilter)
      {
	      endPos = matchDataString.find(",", startPos);
      }
      else
      {
	      endPos = matchDataString.find("|", startPos);
      }
	    if (endPos == string::npos) endPos = matchDataString.length();
	    valueText = matchDataString.substr(startPos, (endPos-startPos));
	    startPos = endPos + 1;
	  }
	 
	  Filter::Operation op = Filter::EQUALS;
	  if (isFilter)
	  {
	    endPos = matchDataString.find("|", startPos);
	    if (endPos == string::npos) endPos = matchDataString.length();
	    string operationString = matchDataString.substr(startPos, endPos-startPos);
      startPos = endPos + 1; // for the pipe
	  long long operationInt = StringUtil::try_stol(operationString, "Parsing operation string");
	  if (operationInt == LONG_MAX) return filters;
	    op = (Filter::Operation)operationInt;
	    // Skip invalid filter combination
	    if (op == Filter::LIKE && type != Filter::STRING)
	    {
	      continue;
	    }
	  }
	  try
	  {
		  Filter filter(key, valueText, op, type);
		  filters.push_back(filter);
	  }
	  catch (const string& e)
	  {
		  cerr << e << endl;
	  }
  } 

  return filters;
}

vector<Filter> MatchUpServer::ParseCreateMatchRequest(string matchDataString, string* matchName, int* maxPlayers)
{
  size_t startPos = 0;
  size_t endPos = 0;
  
  *matchName = StringUtil::parseQuoted(matchDataString, startPos, &endPos);
  
  startPos = endPos + 1;
  endPos = matchDataString.find("|", startPos);
  if (endPos == string::npos)
  {
    endPos = matchDataString.length();
  }
  string maxPlayersStr = matchDataString.substr(startPos, endPos - startPos);
  long long maxPlayersInt = StringUtil::try_stol(maxPlayersStr, "Parsing max players");
  if (maxPlayersInt == LONG_MAX) throw string("Failed parsing create match request");
  *maxPlayers = (int)maxPlayersInt;
  
  vector<Filter> filters;

  if (endPos != matchDataString.length())
  {
    string theRestOfTheString = matchDataString.substr(endPos+1);
    filters= MatchUpServer::ParseFilters(theRestOfTheString, false);
  }
  return filters;
}

string MatchUpServer::GetMatch(sqlite3* db, long long matchID)
{
	string q;
	q = "SELECT id FROM Matches";
	q += " WHERE MATCHES.id = ?" ;
	sqlite3_stmt *st;
	bool success = DB::Prep(db, &st, q, "GetMatch preparing sql statement");
	if (!success) return "";

	success = DB::Bind(db, st, 1, matchID, "GetMatch binding filter key");
	if (!success) return "";

	string responseText = "";

	int resultCode;
	success = DB::Step(db, st, "GetMatch fetching results", &resultCode);
	if (!success) return "";

	if (resultCode == SQLITE_ROW)
	{	
		string matchDataString = "";
		int numDatas = 0;

		responseText += to_string(matchID);

		string intData = EncodeMatchData(db, matchID, Filter::INT, &numDatas);
		if (intData != "") matchDataString += intData + "|";

		string floatData = EncodeMatchData(db, matchID, Filter::FLOAT, &numDatas);
		if (floatData != "") matchDataString += floatData + "|";

		string stringData = EncodeMatchData(db, matchID, Filter::STRING, &numDatas);
		if (stringData != "") matchDataString += stringData + "|";

		if (numDatas > 0)
		{
			responseText += "," + to_string((long long)numDatas);
			responseText += "|";
			responseText += matchDataString;
		}
	}

	sqlite3_finalize(st);

	// Remove trailing pipe
	responseText = responseText.substr(0, responseText.length() - 1);
	return responseText;
}

string MatchUpServer::GetMatchList(sqlite3* db, vector<Filter> filters, long long page, long long resultsPerPage, bool includeMatchData)
{
  // prepare our sql statements
  string q;
  q = "SELECT id, name FROM Matches ";
  q += "WHERE maxClients > (";
  q += " SELECT COUNT(*) ";
  q += " FROM Clients ";
  q += " WHERE Clients.matchID = Matches.id ";
  q += ") ";
  for (size_t i = 0; i < filters.size(); i++)
  {
    Filter filter = filters[i];
    string tableName = Filter::TYPE_TABLES[(int)filter.valueType];
    q += "AND EXISTS ( ";
    q += "  SELECT * FROM " + tableName;
    q += "  WHERE " + tableName + ".matchID = Matches.id ";
    q += "  AND key = ? ";
    q += "  AND value " + Filter::OPS[filter.operation] + " ? " ;
    q += ") ";
  }
  q += " ORDER BY Matches.id DESC LIMIT ?, ?";
  sqlite3_stmt *st;
  bool success = DB::Prep(db, &st, q, "GetMatchList preparing sql statement");
  if (!success) return "";

  int i = 1;
  for (size_t filterIndex = 0; filterIndex < filters.size(); filterIndex++)
  {
    Filter filter = filters[filterIndex];
    success = DB::Bind(db, st, i, filter.key, "GetMatchList binding filter key");
    if (!success) return "";
    i++;

    switch(filter.valueType)
    {
      case Filter::STRING:
        {
          string stringVal = filter.stringValue;
          if (filter.operation == Filter::LIKE) stringVal = "%" + stringVal + "%";
          success = DB::Bind(db, st, i, stringVal, "GetMatchList binding filter string value");
        }
        break;
      case Filter::FLOAT:
        success = DB::Bind(db, st, i, filter.floatValue, "GetMatchList binding filter float value");
        break;
      case Filter::INT:
        success = DB::Bind(db, st, i, filter.intValue, "GetMatchList binding filter int value");
        break;
    }
    if (!success) return "";
    i++;
  }

  success = DB::Bind(db, st, i, page*resultsPerPage, "GetMatchList bind offset");
  if (!success) return "";
  i++;

  success = DB::Bind(db, st, i, resultsPerPage, "GetMatchList bind limit");
  if (!success) return "";
  i++;

  string responseText = "";
  while(true)
  {
    int resultCode;
    success = DB::Step(db, st, "GetMatchList fetching results", &resultCode);
    if (!success) return "";

    if (resultCode == SQLITE_ROW)
    {
      long id = (long)sqlite3_column_int64(st, 0);
      string name = (char*)sqlite3_column_text(st, 1);

      responseText += to_string(id);
      responseText += ",\"" + name + "\"";
      if (includeMatchData)
      {
        string matchDataString = "";
        int numDatas = 0;
    
        string intData = EncodeMatchData(db, id, Filter::INT, &numDatas);
        if (intData != "") matchDataString += intData + "|";
    
        string floatData = EncodeMatchData(db, id, Filter::FLOAT, &numDatas);
        if (floatData != "") matchDataString += floatData + "|";
    
        string stringData = EncodeMatchData(db, id, Filter::STRING, &numDatas);
        if (stringData != "") matchDataString += stringData + "|";
    
        if (numDatas > 0)
        {
          responseText += "," + to_string((long long)numDatas);
          responseText += "|";
          responseText += matchDataString;
        }
      }
      else
      {
        responseText += "|";
      }
    }
    else 
    {
      break;
    }
  }
  
  sqlite3_finalize(st);

  // Remove trailing pipe
  responseText = responseText.substr(0, responseText.length()-1);
  return responseText;
}

string MatchUpServer::EncodeMatchData(sqlite3* db, long long matchID, Filter::ValueType type, int* numDatas)
{
  string tableName = Filter::TYPE_TABLES[(int)type];
  string q = "SELECT key, value FROM " + tableName + "  WHERE " + tableName + ".matchID = ? ";

  sqlite3_stmt *st;
  bool success = DB::Prep(db, &st, q, "EncodeMatchData preparing sql statement");
  if (!success) return "";

  success = DB::Bind(db, st, 1, matchID, "EncodeMatchData binding matchID");
  if (!success) return "";

  string encodedString;
  while(true)
  {
    int result;
    success = DB::Step(db, st, "EncodeMatchData fetching results", &result);
    if (!success) return "";

    if (result == SQLITE_ROW)
    {
      string key = (char*)sqlite3_column_text(st, 0);
      string valueText;
      switch (type)
      {
        case Filter::INT:
          valueText = to_string((long long)sqlite3_column_int64(st, 1));
          break;
        case Filter::FLOAT:
          valueText = to_string((long long)sqlite3_column_double(st, 1));
          break;
        case Filter::STRING:
          valueText = "\"" + string((char*)sqlite3_column_text(st, 1)) + "\"";
          break;
      }
      encodedString += to_string((long long)(int)type) + "," + key + "," + valueText + "|";
      *numDatas = *numDatas + 1;
    }
    else if (result == SQLITE_DONE)
    {
      break;
    }
  }
  if (encodedString != "") encodedString = encodedString.substr(0, encodedString.length()-1);

  sqlite3_finalize(st);

  return encodedString;
}
