#ifndef __SERVER_H__
#define __SERVER_H__

#if _WIN32 || _WIN64
#include <WinSock2.h>
#include <WS2tcpip.h>
//#include <Windows.h>
#pragma comment(lib, "ws2_32")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>
#endif

#include <iostream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>

class Client;

using namespace std;

/**
 * Just your standard multithreaded socket server.
 * Supports IPv6.
 */
class Server 
{

  private:
    // A list of connected clients
    static vector<Client*> clients;

    //Socket stuff
	int serverSocks[FD_SETSIZE];
    int clientSock;
	int numServerSocks;
    short port;
	static bool shuttingDown;
	#if _WIN32 || _WIN64
		SOCKADDR_STORAGE serverAddr, clientAddr;
	#else
		struct sockaddr_in6 serverAddr, clientAddr;
	#endif
    char buff[256];

  public:
    /**
     * Create a new server listening on the specified port and IP.
     * If no IP is specified it will listen on all.
     */
    Server(string* ip, int ipCount, short port);

    /**
     * Clean up the clients and cancel their threads
     */
    static void CleanUp();

    /**
     * Loop forever listening for incoming connections.
     */
    void AcceptAndDispatch();

	static void DisconnectClient(Client* c);

	static void* KeepClientAlive(void *args);

    /**
     * Whenever a connection is made a new thread is started
     * to listen for incoming data on that connection.
     */
    static void* HandleClient(void *args);

    /**
     * Send a message to call connected clients
     */
    static void SendToAll(char *message);

    /**
     * Send a message to a specific client identified by their socketID.
     */
    static void SendToClient(int socketID, string message, string transactionID = "");

    /**
     * Find the index of a specifc client in the list of clients
     */
    static int FindClientIndex(Client *c); 

    /**
     * Handle clean up that results from a thread being killed
     * while litening on a socket because I am a good boyscout.
     */
    static void ClientThreadCleanupHandler(void* arg);
};

#endif
