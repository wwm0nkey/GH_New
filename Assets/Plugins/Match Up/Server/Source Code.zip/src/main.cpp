#if defined(_WIN32) || defined(_WIN64)
#include <WinSock2.h>
#include <WS2tcpip.h>
//#include <Windows.h>
#pragma comment(lib, "ws2_32")
#else
#include <unistd.h>
#include <ifaddrs.h>
#include <netinet/in.h> 
#include <arpa/inet.h>
#endif
#include <sys/types.h>
#include <string.h> 
#include <iostream>
#include "MatchUpServer.h"
#include "optionparser.h"
#include "Debug.h"
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

// Handle exit signal (Ctr-c)
#if defined(_WIN32) || defined(_WIN64)
BOOL exitHandler(DWORD fdwCtrlType)
{
	printf("\nGoodbye :)\n");
	MatchUpServer::CleanUp();
	return FALSE;
}
#else
void exitHandler(int s)
{
  MatchUpServer::CleanUp();
  // Intentionally using printf instead of cout to avoid GLIBCXX_3.4.9 dependence
  printf("\nGoodbye :)\n");
  exit(s); 
}
#endif

// Define the command line options
enum  optionIndex { PORT, IP, HELP, UNKNOWN, VERBOSE };
const option::Descriptor usage[] =
{
  {
    UNKNOWN, 0, "" , "", option::Arg::None, 
    "\nOptions:" 
  },
  {
    PORT, 0, "p", "port",   option::Arg::Numeric, 
    "  --port, -p \tExplicitly set the port to host on. Defaults to 20203." 
  },
  {
    IP, 0, "i", "ip", option::Arg::Required,
	"  --ip \tExplicitly set the IP(s) to host on. Separate multiple IP Addresses with commas." 
  },
  {
    VERBOSE, 0, "v", "verbose", option::Arg::None,
    "  --verbose, -v \tShow more output." 
  },
  {
    HELP, 0, "h", "help", option::Arg::None, 
    "  --help, -h \tPrint usage and exit.\n" 
  },
  {0,0,0,0,0,0}
};

#if defined(_WIN32) || defined(_WIN64)
void printIP()
{
	Debug::Log("IP Addresses: ", true);
	int i; 
	void * tmpAddrPtr = NULL;
	ADDRINFO Hints, *AddrInfo, *AI;
	memset(&Hints, 0, sizeof(Hints));
	Hints.ai_family = PF_UNSPEC; // Accept either IPv4 or IPv6
	Hints.ai_socktype = SOCK_STREAM; // TCP
	int getAddrResult = getaddrinfo(NULL, "20203", &Hints, &AddrInfo);
	if (getAddrResult != 0)
	{
		string error = "getaddrinfo failed with error " + to_string(getAddrResult) + ": " + gai_strerror(getAddrResult);
		throw error;
	}

	for (i = 0, AI = AddrInfo; AI != NULL; AI = AI->ai_next, i++)
	{
		if (AI->ai_family == AF_INET)
		{
			struct sockaddr_in* sockAddr = (struct sockaddr_in*)AI->ai_addr;

			tmpAddrPtr = &(sockAddr)->sin_addr;
			char addressBuffer[INET_ADDRSTRLEN];
			inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
			Debug::Log("\t" + string(addressBuffer), true);
		}
		else if (AI->ai_family == AF_INET6)
		{
			struct sockaddr_in6* sockAddr = (struct sockaddr_in6*)AI->ai_addr;

			// is a valid IP6 Address
			tmpAddrPtr = &(sockAddr)->sin6_addr;
			char addressBuffer[INET6_ADDRSTRLEN];
			inet_ntop(AF_INET6, tmpAddrPtr, addressBuffer, INET6_ADDRSTRLEN);
			Debug::Log("\t" + string(addressBuffer), true);
		}
	}
	freeaddrinfo(AddrInfo);
}
#else
void printIP()
{
  Debug::Log("IP Addresses: ", true); 
  struct ifaddrs * ifAddrStruct=NULL;
  struct ifaddrs * ifa=NULL;
  void * tmpAddrPtr=NULL;

  getifaddrs(&ifAddrStruct);

  for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) 
  {
    if (!ifa->ifa_addr) continue;

    if (ifa->ifa_addr->sa_family == AF_INET) 
    {
      struct sockaddr_in* sockAddr = (struct sockaddr_in*)ifa->ifa_addr;

      // is a valid IP4 Address
      tmpAddrPtr=&(sockAddr)->sin_addr;
      char addressBuffer[INET_ADDRSTRLEN];
      inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
      Debug::Log("\t" + string(addressBuffer), true); 
    }
    else if (ifa->ifa_addr->sa_family == AF_INET6) 
    {
      struct sockaddr_in6* sockAddr = (struct sockaddr_in6*)ifa->ifa_addr;

      // is a valid IP6 Address
      tmpAddrPtr=&(sockAddr)->sin6_addr;
      char addressBuffer[INET6_ADDRSTRLEN];
      inet_ntop(AF_INET6, tmpAddrPtr, addressBuffer, INET6_ADDRSTRLEN);
      Debug::Log("\t" + string(addressBuffer), true); 
    } 
  }

  if (ifAddrStruct!=NULL) freeifaddrs(ifAddrStruct);
}
#endif

int main(int argc, char* argv[])
{
  // Catch exit signal so we can clean up
  #if defined(_WIN32) || defined(_WIN64)
	SetConsoleCtrlHandler((PHANDLER_ROUTINE)exitHandler, TRUE);
  #else
	struct sigaction sigIntHandler;
	sigIntHandler.sa_handler = exitHandler;
	sigemptyset(&sigIntHandler.sa_mask);
	sigIntHandler.sa_flags = 0;
	sigaction(SIGINT, &sigIntHandler, NULL);
  #endif

  // Parse command line options to get port and ip
  argc-=(argc>0); argv+=(argc>0); // skip program name argv[0] if present
  option::Stats  stats(usage, argc, argv);
  option::Option options[100], buffer[100];// stats.options_max], buffer[stats.buffer_max];
  option::Parser parse(usage, argc, argv, options, buffer);

  if (options[HELP]) 
  {
    option::printUsage(std::cout, usage);
    return 0;
  }

  if (options[VERBOSE]) Debug::isVerbose = true;
  else Debug::isVerbose = false;

  // Port
  int port = 20203;
  if (options[PORT])
  {
    port = atoi(options[PORT].arg);
  }

  string ip[32];
  int ipCount = 0;
  string ipString = "";
  if (options[IP])
  {
	  ipString = options[IP].arg;
	  Debug::Log("Listening on IP(s) " + ipString);
	  string token;
	  while (token != ipString)
	  {
		  if (ipCount == 32) break;
		  token = ipString.substr(0, ipString.find_first_of(","));
		  ipString = ipString.substr(ipString.find_first_of(",") + 1);
		  ip[ipCount] = ipString;
	  }
  }

  #if defined(_WIN32) || defined(_WIN64)
  WSADATA wsaData;
  int startUpResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
  if (startUpResult != NO_ERROR) {
	  wprintf(L"Error at WSAStartup()\n");
	  throw new string("Failed to initialize windows sockets") + startUpResult;
  }
  #endif

  Debug::Log("Listening on port " + to_string((long long)port), true);

  // Blocks until dead
  try 
  {
	printIP();
    MatchUpServer::StartServer(ip, ipCount, port);
  } 
  catch (string& e)
  {
    cerr << e << endl;
	MatchUpServer::CleanUp();
  }

  return 0;
}

