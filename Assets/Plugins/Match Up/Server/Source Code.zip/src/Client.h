#ifndef __CLIENT_H__
#define __CLIENT_H__

#include <time.h>  

class ThreadHandler;
struct sqlite3;

using namespace std;

/**
 * Represents a single connected client.
 * Each client has their own database connection to prevent
 * issues with multithreading.
 */
class Client 
{
  public:
    // The id of the socket the client connected on
    int socketID; 
    // The client's connection to the database
    sqlite3 *db;
    // We basically just store this so we can clean it up
    ThreadHandler* threadHandler;
	ThreadHandler* keepAliveThreadHandler;
	time_t lastKeepAliveTime;

  public:

    /**
     * Opens the connection to the database
     */
    Client();

    /**
     * Closes the connection to the database and deletes the thread handler.
     */
    ~Client();
    
    /**
     * Called by the Server when it receives a message on the Client's socket.
     * Forwards the message to the MatchUpServer and sends the response out.
     */
    void ReceivedMessage(char* message);

    /**
     * The Server calls this when the Client's socket disconnects.
     * Just forwards the message along to the MatchUpServer.
     */
    void Disconnect();
};

#endif
