#include "Server.h"
#include "Debug.h"
#include "Client.h"
#include "ThreadHandler.h"
#include <chrono>
#include <thread>

using namespace std;

// This stuff makes it a little easier to code sockets for windows and linux simultaneously
#if defined(_WIN32) || defined(_WIN64)
  // On windows addrinfo needs to be all caps
  #define addrinfo ADDRINFO
#else
  // Linux does not include the INVALID_SOCKET define and instead uses -1
  #define INVALID_SOCKET -1
  #define SOCKET_ERROR -1

  // Linux uses snprintf instead of sprintf_s, this fixes that so we can use sprintf_s everywhere
  template<typename... Args> int sprintf_s(char *buffer, size_t sizeOfBuffer, const char *format, Args... args)  
  {
    return snprintf(buffer, sizeOfBuffer, format, args...);
  }
  template<typename... Args> int sprintf_s(char *buffer, const char *format, Args... args) 
  {
    return sprintf(buffer, format, args...);
  }
  // Linux uses errno instead of WSAGetLastError()
  int WSAGetLastError()
  {
    return errno;
  }
  // Linux uses close instead of closesocket
  void closesocket(int socket)
  {
    close(socket);
  }
#endif

//Actually allocate clients
vector<Client*> Server::clients;
bool Server::shuttingDown = false;

Server::Server(string* ip, int ipCount, short port)
{
	// Initialize static mutex from ThreadHandler
	bool success = ThreadHandler::InitMutex();
	if (!success)
	{
		throw string("Failed to initialize mutex");
	}

	// Init serverSock and start listen()'ing

	// Populate an addrinfo structure with some hints that we'll use 
	// to query the system for available addresses to host on
	addrinfo Hints;
	memset(&Hints, 0, sizeof(Hints)); // Initialize everything to 0
	Hints.ai_family = PF_UNSPEC; // Accept either IPv4 or IPv6
	Hints.ai_socktype = SOCK_STREAM; // TCP
	Hints.ai_flags = AI_NUMERICHOST | AI_PASSIVE; // Address will be used for binding (hosting) and will be numeric

	// Copy the passed in port number to a cstring because that's what getaddrinfo wants
	char Port[10];
	sprintf_s(Port, "%i", port);

	// This will be a linked list of addrinfo structures
	addrinfo *addressList = NULL;

	// If no IP's are passed in then we get all available addresses that we can host on
	if (ipCount == 0)
	{
		int getAddrResult = getaddrinfo(NULL, Port, &Hints, &addressList);
		if (getAddrResult != 0)
		{
			char error[128];
			sprintf_s(error, "getaddrinfo failed with error %d: %s\n", getAddrResult, gai_strerror(getAddrResult));
			throw string(error);
		}
	}
	// If a list of IP's was passed in then we get all addresses that match those IPs
	else
	{
		for (int ipIndex = 0; ipIndex < ipCount; ipIndex++)
		{
			// Convert ip to a cstring because that's what getaddrinfo wants
			const char *ipAddress = ip[ipIndex].c_str();

			// Get the list of addresses that match this IP. There can be more than one address
			// structure returned for each IP for reasons I don't fully understand
			addrinfo *partial;
			int getAddrResult = getaddrinfo(ipAddress, Port, &Hints, &partial);
			if (getAddrResult != 0)
			{
				char error[128];
				sprintf_s(error, "getaddrinfo failed with error %d: %s\n", getAddrResult, gai_strerror(getAddrResult));
				throw string(error);
			}

			// If the addressList is null then just set it to the partial list
			if (addressList == NULL)
			{
				addressList = partial;
			}
			// If the addressList is not null then we append the partial list to the front of the existing list
			else
			{
				// Attach the linked lists
				// First find the last node of the new partial list
				addrinfo* last = partial;
				while (last->ai_next != NULL)
				{
					last = last->ai_next;
				}
				// Then point it to the first node in the full list
				last->ai_next = addressList;
				// Then reposition the start of the full list at the new beginning
				addressList = partial;
			}
		}
	}

	// For each address in the addressList we create a new socket,
	// bind that address to it, and create a queue to listen on.
	int i;
	addrinfo *AI;
	for (i = 0, AI = addressList; AI != NULL; AI = AI->ai_next, i++)
	{
		// Highly unlikely, but check anyway.
		if (i == FD_SETSIZE) 
		{
			Debug::Log("Warning: getaddrinfo returned more addresses than we could use.", true);
			break;
		}

		// Only supports INET and INET6.
		if ((AI->ai_family != PF_INET) && (AI->ai_family != PF_INET6))
		{
			continue;
		}

		// Open a socket with the correct address family for this address.
		serverSocks[i] = socket(AI->ai_family, AI->ai_socktype, AI->ai_protocol);

		if (serverSocks[i] == INVALID_SOCKET)
		{
			char error[128];
			sprintf_s(error, "socket() failed with error %d\n", WSAGetLastError());
			throw string(error);
		}

		// Set some useful options on our new socket
		#if defined(_WIN32) || defined(_WIN64)
		// Avoid bind error if the socket was not close()'d last time;
		setsockopt(serverSocks[i], SOL_SOCKET, SO_REUSEADDR, (const char*)TRUE, sizeof(const char));
		// Make sure IPv6 only is not on, this seems to work fine in windows despite being a problem on linux
		setsockopt(serverSocks[i], IPPROTO_IPV6, IPV6_V6ONLY, (const char*)FALSE, sizeof(const char));
		#else
		int yes = 1;
  		//int no = 0;
		// Avoid bind error if the socket was not close()'d last time;
  		setsockopt(serverSocks[i], SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
  		// I think because we're starting a socket for every interface / address
		// we want IPV6_V6ONLY to be on, otherwise ipv6 addresses are started
		// as dual stack which blocks the ipv4 version from starting or something
  		setsockopt(serverSocks[i], IPPROTO_IPV6, IPV6_V6ONLY, &yes, sizeof(int));
		#endif

		// Bind the socket to the address
		int result = ::bind(serverSocks[i], AI->ai_addr, AI->ai_addrlen);

		if (result < 0)
		{
			Debug::Log("Warning: Failed to bind socket: " + to_string(WSAGetLastError()), true);
			closesocket(serverSocks[i]);
			continue;
		}
		else
		{
			// Put socket into listen mode
			listen(serverSocks[i], 5);
		}
	}
	// Keep track of how many sockets we've got
	numServerSocks = i;
	// Free the addressList to prevent memory leaks
	freeaddrinfo(addressList);
}

// static
void Server::CleanUp()
{
	shuttingDown = true;
  for (size_t i = 0; i < clients.size(); i++)
  {
    Client* client = clients[i];
	#if defined(_WIN32) || defined(_WIN64)
	// Thread clean up handler is not called automatically on windows so we call it manually
	Server::ClientThreadCleanupHandler((void *)&client->socketID);
	#endif
    pthread_cancel(client->threadHandler->tid);
    client->threadHandler->Cancel();
    client->threadHandler->Join();
    pthread_join(client->threadHandler->tid, NULL);
    delete client;
  }

  #if defined(_WIN32) || defined(_WIN64)
  WSACleanup();
  #endif
}

/*
  AcceptAndDispatch();

  Main loop:
    Blocks at select(), until a new connection arrives.
    When it happens, create a new thread to handle the new client.
*/
void Server::AcceptAndDispatch() 
{
	Client *c;
	ThreadHandler *t;

	fd_set SockSet;
	FD_ZERO(&SockSet);
	while(!shuttingDown) 
	{
		int i;
		// Check to see if we have any sockets remaining to be served
		// from previous time through this loop.  If not, call select()
		// to wait for a connection request.
		for (i = 0; i < numServerSocks; i++)
		{
			if (FD_ISSET(serverSocks[i], &SockSet))
			{
				break;
			}
		}
		if (i == numServerSocks) 
		{
			// We need to know the max socket id to pass in to select()
			int maxSocketID = -1;
			for (i = 0; i < numServerSocks; i++)
			{
				FD_SET(serverSocks[i], &SockSet);
				if (serverSocks[i] > maxSocketID) maxSocketID = serverSocks[i];
			}
			// Blocks here to wait for new connection on any socket in the set
			if (select(maxSocketID + 1, &SockSet, 0, 0, 0) == SOCKET_ERROR)
			{
				Debug::Log("select() failed with error: " + to_string(WSAGetLastError()), true);
				break;
			}
		}
		for (i = 0; i < numServerSocks; i++) 
		{
			if (FD_ISSET(serverSocks[i], &SockSet)) 
			{
				FD_CLR(serverSocks[i], &SockSet);
				break;
			}
		}

		if (shuttingDown) break;

		// If we are here then a client has connected
		c = new Client();

		// Accept the client connection and keep track of the client socket ID
		c->socketID = accept(serverSocks[i], NULL, NULL);

		if(c->socketID < 0) 
		{
			Debug::Log("Error on accept: " + to_string(WSAGetLastError()), true);
		}
		else 
		{
			// Launch a new thread to listen on the client socket
			t = new ThreadHandler();
			c->threadHandler = t;
			t->Create((void *) Server::HandleClient, c);

			t = new ThreadHandler();
			c->keepAliveThreadHandler = t;
			t->Create((void *)Server::KeepClientAlive, c);
		}
	}
}

//Static
void* Server::KeepClientAlive(void *args)
{
	//Pointer to accept()'ed Client 
	Client *c = (Client *)args;

	while (!shuttingDown)
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
		if (shuttingDown) break;
		ThreadHandler::LockMutex("Checking keepalive timeout");
		long long lastKeepAlive = c->lastKeepAliveTime;
		ThreadHandler::UnlockMutex("Checking keepalive timeout");
		time_t curTime;
		time(&curTime);
		if ((curTime - lastKeepAlive) > 60)
		{
			closesocket(c->socketID);
			return NULL;
		}
	}

	return NULL;
}

void Server::DisconnectClient(Client* c)
{
	Debug::Log("Client with socket id " + to_string((long long)c->socketID) + " diconnected");
#if defined(_WIN32) || defined(_WIN64)
	closesocket(c->socketID);
#else
	close(c->socketID);
#endif

	//Remove client in Static clients <vector> (Critical section!)
	ThreadHandler::LockMutex(to_string((long long)c->socketID).c_str());

	int index = Server::FindClientIndex(c);
	Server::clients.erase(Server::clients.begin() + index);

	ThreadHandler::UnlockMutex(to_string((long long)c->socketID).c_str());

	c->Disconnect();

	delete c;
}

//Static
void Server::ClientThreadCleanupHandler(void* args)
{
  #if defined(_WIN32) || defined(_WIN64)
    SOCKET socket = *(SOCKET*)args;
    closesocket(socket);
  #else
    int socket = *(int*)args;
    close(socket);
  #endif
}

//Static
void *Server::HandleClient(void *args) 
{
  //Pointer to accept()'ed Client 
  Client *c = (Client *) args;

  Debug::Log("Client with socket id " + to_string((long long)c->socketID) + " connected");

  pthread_cleanup_push(Server::ClientThreadCleanupHandler, &(c->socketID));
  char buffer[2048];
  int n;

  //Add client in Static clients <vector> (Critical section!)
  ThreadHandler::LockMutex(to_string((long long)c->socketID).c_str());
  
    Server::clients.push_back(c);

  ThreadHandler::UnlockMutex(to_string((long long)c->socketID).c_str());

  while(!shuttingDown) 
  {
    memset(buffer, 0, sizeof buffer);
    n = recv(c->socketID, buffer, sizeof buffer, 0);

	if (shuttingDown) break;

    //Client disconnected?
    if(n <= 0) 
    {
		Server::DisconnectClient(c);

      break;
    }
    else {
      c->ReceivedMessage(buffer);
    }
  }
  pthread_cleanup_pop(0);
  pthread_detach(pthread_self());
  pthread_exit(NULL);
  //End thread
  return NULL;
}

void Server::SendToAll(char *message)
{
  //Acquire the lock
  ThreadHandler::LockMutex("SendToAll");
 
    for(size_t i = 0; i < clients.size(); i++) {
      send(Server::clients[i]->socketID, message, strlen(message), 0);
    }
   
  //Release the lock  
  ThreadHandler::UnlockMutex("SendToAll");
}

void Server::SendToClient(int socketID, string message, string transactionID) 
{
	if (transactionID == "")
	{
		message = message + "\n";
	}
	else
	{
		message = transactionID + "|" + message + "\n";
	}

  //Acquire the lock
  ThreadHandler::LockMutex("SendToClient");
 
    for(size_t i = 0; i < clients.size(); i++)
    {
      if (clients[i]->socketID == socketID)
      {
        send(Server::clients[i]->socketID, message.c_str(), message.length(), 0);
        break;
      }
    }
   
  //Release the lock  
  ThreadHandler::UnlockMutex("SendToClient");
}

/*
  Should be called when vector<Client> clients is locked!
*/
int Server::FindClientIndex(Client *c) 
{
  for(size_t i = 0; i < clients.size(); i++) 
  {
    if((Server::clients[i]->socketID) == c->socketID) return (int) i;
  }
  Debug::Error("Client id not found.");
  return -1;
}

