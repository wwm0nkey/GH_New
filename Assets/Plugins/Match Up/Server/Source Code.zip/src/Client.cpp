#include "Client.h"
#include "Server.h"
#include "Debug.h"
#include "MatchUpServer.h"
#include "sqlite/sqlite3.h"
#include "ThreadHandler.h"

using namespace std;

Client::Client()
{
  // Open database
  int rc = sqlite3_open("MatchUpServer.db", &db);
  if(rc)
  {
    Debug::Error("Can't open database");
    return;
  }

  time(&lastKeepAliveTime);

  // Turn foreign keys on so we can take advantage of constraints
  char* err;
  string q = "PRAGMA foreign_keys = on";
  sqlite3_exec(db, &q[0], NULL, 0, &err);
  if (err) Debug::SqlError(err);
}

Client::~Client()
{
  // close database
  if(db)
  {
    sqlite3_close(db);
  }

  // Free the client's thread handler
  delete threadHandler;
  delete keepAliveThreadHandler;
}

void Client::ReceivedMessage(char* message)
{
  if (message[0] == '\n') 
  {
	  char keepAlive[1] = { '\n' };
	  send(socketID, keepAlive, 1, 0);
	  time(&lastKeepAliveTime);
	  return;
  }
  string messageString(message);
  string transactionID;
  // Pass the message off to the MatchUpServer to handle
  string response = MatchUpServer::ReceivedCommand(message, db, socketID, &transactionID);
  // Send the response back out to the client.
  Server::SendToClient(socketID, response, transactionID);
}

void Client::Disconnect()
{
  MatchUpServer::HandleSocketDisconnect(db, socketID);
}
