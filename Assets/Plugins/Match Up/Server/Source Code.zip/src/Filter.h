#ifndef __FILTER_H__
#define __FILTER_H__

#include <iostream>
#include <string>
#include "StringUtil.h"

using namespace std;

/**
 * Filters objects are used to limit the results of GetMatchList() calls
 */
struct Filter 
{
  // Available filter operations
  enum Operation
  {
    EQUALS, NOT_EQUALS, LIKE, NOT_LIKE, LESS, GREATER
  };

  // Friendly strings for each operation for outputting to console
  static const string OPS[6];

  // Available data types
  enum ValueType
  {
    STRING, INT, FLOAT
  };

  // Friendly strings for each data type for outputting to the console
  static const string TYPES[3];
  // The sql table name associated with each data type.
  static const string TYPE_TABLES[3];

  // They key of the data to filter on
  string key;

  // The value to filter against 
  string stringValue;
  long long intValue;
  double floatValue;

  // The operation to use when filtering
  Operation operation;
  // The type of the data this filter applies to
  ValueType valueType;

public:
  /**
   * Create a new Filter.
   */
  Filter(string key, string value, Operation op, ValueType type)
  {
    this->key = key;
    this->operation = op;
    this->valueType = type;
    this->stringValue = value;

    switch (type) 
    {
      case STRING: 
		  stringValue = value; 
		  break;
      case INT: 
		  intValue = StringUtil::try_stol(value, "Parsing filter int value");
		  if (intValue == LONG_MAX) throw string("Failed to parse filter value");
		  break;
      case FLOAT: 
		  floatValue = StringUtil::try_stod(value, "Parsing filter float value");
		  if (floatValue == DBL_MAX) throw string("Failed to parse filter value");
		  break;
    }
  }

  /**
   * Convert the filter to a string for outputting to the console
   */
  string toString()
  {
    if (valueType == STRING)
    {
      return "Filter: [" + key + " " + OPS[(int)operation] + " \"" + stringValue + "\" (" + TYPES[(long)valueType] + ")]";
    }
    else
    {
      return "Filter: [" + key + " " + OPS[(int)operation] + " " + stringValue + " (" + TYPES[(long)valueType] + ")]";
    }
  }
  
};

#endif
