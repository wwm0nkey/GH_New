#ifndef __MATCH_UP_SERVER__
#define __MATCH_UP_SERVER__

#include <iostream>
#include <vector>
#include "sqlite/sqlite3.h"
#include "Filter.h"

using namespace std;

class Server;

/**
 * Receives Commands from Clients and executes them.
 * Manages the creation, modification, and deletion of everything related to matches, including clients and match data
 */
class MatchUpServer
{
public:

  // The available commands
  enum Command { 
  	GET_MATCH,
    GET_MATCH_LIST, 
    CREATE_MATCH, 
    DESTROY_MATCH, 
    ADD_CLIENT_TO_MATCH, 
    REMOVE_CLIENT_FROM_MATCH,
    SET_MATCH_DATA
  };

  // Friendly string representation of the command for outputting to the console
  static const string COMMANDS[7];

private:
  // The server that was use to send outgoing responses
  static Server* server;

public:

  /**
   * Start the server and start listening for incoming connections
   * This blocks forever until the program is killed.
   *
   * Also initialized the connection to the database and creates tables if necessary.
   */
  static void StartServer(string* ip, int ipCount, int port);

  /**
   * Shuts down the server and closes the connection to the db
   */
  static void CleanUp();

  /**
   * Get a match list and a send it back to the requesting client.
   * Supports filtering and pagination.
   * The filterString can contain as many filters as you want separated by "|"
   * Filters should be in the form:
   * 
   * filterKey,filterValue,valueType,operation
   * 
   * Where:
   *    filterKey is the name of the field to filter on
   *    filterValue is the value to compare to
   *    valueType is the data type of the value. 0 = string, 1 = int, 2 = float
   *    operation is the operation to use when filtering. 0 = equals, 1 = LIKE, 2 = less than, 3 = greater than
   *
   * An example filterString might look like:
   *    eloScore,100,1,3|eloScore,200,1,2
   * 
   * Which would find all matches that have an eloScore between 100 and 200.
   */
  static string GetMatchList(sqlite3* db, vector<Filter> filters, long long page, long long resultsPerPage, bool includeMatchData);

  /**
  * Get a match according to matchID and send it back to the requesting client.
  */
  static string GetMatch(sqlite3* db, long long matchID);

  /**
   * Create a new match and send the match id and clientID back to the client.
   * Also stores match data if provided.
   */
  static string CreateMatch(sqlite3* db, int socketID, string matchName, int maxClients, vector<Filter> matchData);

  /**
   * Add a client to a match. The only effect this really has is that when a match is full
   * it will no longer show up in match lists until a client leaves to make room
   */
  static string AddClientToMatch(sqlite3* db, int socketID, long long matchID);

  /**
   * Clear all data associated with the specified match.
   */
  static string ClearMatchData(sqlite3* db, long long matchID);

  /**
   * Clear all match data of a specific type that is associated with the specified match
   */
  static bool ClearMatchDataForType(sqlite3* db, long long matchID, Filter::ValueType type);

  /**
   * Add / update match data for the specified match
   */
  static bool SetMatchData(sqlite3* db, long long matchID, vector<Filter> matchData);

  /**
   * Add / update match data of a specific type to the specified match
   */
  static bool SetMatchDataForType(sqlite3* db, long long matchID, vector<Filter> matchData, Filter::ValueType type);

  /**
   * MatchData keys must be unique per match. This method cleans up existing data before adding new ones so that
   * we can avoid conflicts across separate match data tables that the table constraints alone can't catch
   */
  static bool DeleteConflictingDataForType(sqlite3* db, long long matchID, vector<Filter> matchData, Filter::ValueType type);

  /**
   * Remove all cleints from a match. This includes the host.
   */
  static string RemoveAllClientsFromMatch(sqlite3* db, long long matchID);

  /**
   * Remove a specific client from a match. If the match is full (and thus not showing up in match lists) 
   * it will become discoverable again once a client is removed.
   */
  static string RemoveClientFromMatch(sqlite3* db, long long clientID);

  /**
   * Destroy a match and all associated clients and match data
   */
  static string DestroyMatch(sqlite3* db, long long matchID);

  /**
   * Does some complex parsing to convert text sent by a client into a list of Filter objects
   */
  static vector<Filter> ParseFilters(string filterString, bool isFilter = true);

  /**
   * Parse a CreateMatch request to extract the matchName, maxPlayers and match data
   */
  static vector<Filter> ParseCreateMatchRequest(string matchDataString, string* matchName, int* maxPlayers);

  /**
   * All commands are received here and then routed to the appropriate method
   */
  static string ReceivedCommand(string message, sqlite3* db, int socketID, string* transactionID);

  /**
   * Encode some match data as a string for sending to a client
   */
  static string EncodeMatchData(sqlite3* db, long long matchID, Filter::ValueType type, int* numDatas);

  /**
   * When a client disconnects from the socket we assume they are gone and nuke
   * any matches they are a host of as well as their client record in the db.
   */
  static void HandleSocketDisconnect(sqlite3* db, int socketID);

  /**
   * Set the match host. This is called after the match is created and 
   * the host's client record has been added to the db.
   */
  static bool SetMatchHost(sqlite3* db, long long matchID, long long clientID);

  /**
   * Destroy all matches
   */
  static void ClearMatches(sqlite3* db);

  /**
   * Called by HandleSocketDisconnect to obliterate any matches associated
   * with the disconnecting socket.
   */
  static void DestroyMatchForSocket(sqlite3* db, int socketID);

  /**
   * Called by HandleSocketDisconnect to obliterate any clients associated
   * with the disconnecting socket.
   */
  static void RemoveClientForSocket(sqlite3* db, int socketID);
  
};

#endif
